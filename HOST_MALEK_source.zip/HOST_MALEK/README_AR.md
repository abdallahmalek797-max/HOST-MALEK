# HOST MALEK ⚡🔥

مشروع بداية لتطبيق أندرويد لإضافة وتشغيل ملفات Python متعددة.

## المتطلبات
- Android Studio حديث.
- JDK 17.
- Android SDK Platform 35.
- اتصال إنترنت أثناء أول Gradle Sync لتنزيل Chaquopy والمكتبات.

## فتح المشروع وبناء APK
1. فك ضغط `HOST_MALEK.zip`.
2. افتح مجلد `HOST_MALEK` في Android Studio.
3. انتظر Gradle Sync.
4. من القائمة اختر Build > Build Bundle(s) / APK(s) > Build APK(s).
5. ستجد APK داخل `app/build/outputs/apk/debug/`.

## ملاحظات مهمة
- الحد الأدنى Android 8.0 (API 26).
- بيئة Python المضمّنة هي Python 3.11.
- أُضيفت requests و pyTelegramBotAPI وقت بناء APK. إضافة مكتبات أخرى تتطلب تعديل `app/build.gradle` ثم إعادة البناء.
- لا يمكن ضمان تشغيل كل مكتبات Python؛ المكتبات التي تحتاج امتدادات native أو خدمات نظام قد لا تتوافق مع Android.
- تشغيل الملفات يتم داخل بيئة Python المضمّنة. يمكن تشغيل أكثر من بوت، لكن التنفيذ يتشارك مفسر Python واحد وموارد التطبيق.
- زر الإيقاف يرسل طلب إيقاف تعاوني. لا يستطيع Android إيقاف كود Python عشوائي بأمان من منتصف أي تعليمة. لكي يستجيب البوت، يجب أن يفحص `HOST_MALEK_SHOULD_STOP()` داخل حلقاته أو يستخدم `HOST_MALEK_STOP_EVENT`.
- لا تضع توكنات حساسة في ملفات تشاركها مع الآخرين. خانة التوكن تخزن في ذاكرة التطبيق أثناء التشغيل فقط في هذه النسخة الأولية.
- هذه نسخة أولية للمصدر وليست APK مبنيًا؛ يلزم Android Studio وAndroid SDK لإنتاج APK.
