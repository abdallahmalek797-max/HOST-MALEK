package com.malek.host

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import java.io.File
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val bg = Color.rgb(10, 12, 18)
    private val panel = Color.rgb(23, 27, 38)
    private val red = Color.rgb(255, 55, 75)
    private val blue = Color.rgb(45, 145, 255)
    private val white = Color.WHITE
    private val executor = Executors.newCachedThreadPool()
    private val bots = ConcurrentHashMap<String, Bot>()
    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private var pendingToken = ""

    data class Bot(
        val id: String, val file: File, val token: String,
        @Volatile var running: Boolean = false,
        @Volatile var log: String = ""
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Python.isStarted()) Python.start(AndroidPlatform(this))
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 22, 18, 18)
            setBackgroundColor(bg)
        }
        val title = TextView(this).apply {
            text = "HOST MALEK ⚡🔥"
            textSize = 27f; setTextColor(red); gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        root.addView(title, LinearLayout.LayoutParams(-1, 60))
        val subtitle = TextView(this).apply {
            text = "PYTHON BOT MANAGER  •  MULTI-RUNNER"
            textSize = 11f; setTextColor(blue); gravity = Gravity.CENTER
        }
        root.addView(subtitle, LinearLayout.LayoutParams(-1, 28))

        val add = Button(this).apply {
            text = "＋  إضافة ملف Python"
            setTextColor(white); setBackgroundColor(red)
            setOnClickListener { chooseFile() }
        }
        root.addView(add, LinearLayout.LayoutParams(-1, 52).apply { topMargin = 16; bottomMargin = 10 })

        status = TextView(this).apply {
            text = "اختر ملف .py لإضافته إلى قائمة البوتات"
            textSize = 13f; setTextColor(white)
        }
        root.addView(status, LinearLayout.LayoutParams(-1, 38))

        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val foot = TextView(this).apply {
            text = "Android 8+  |  Python 3.11  |  HOST MALEK"
            textSize = 10f; setTextColor(blue); gravity = Gravity.CENTER
        }
        root.addView(foot, LinearLayout.LayoutParams(-1, 28))
        setContentView(root)
    }

    private fun chooseFile() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        @Suppress("DEPRECATION")
        startActivityForResult(intent, 1001)
    }

    @Deprecated("Deprecated by platform API; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1001 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                val name = queryName(uri) ?: "bot_${System.currentTimeMillis()}.py"
                if (!name.endsWith(".py", true)) {
                    toast("اختار ملف Python امتداده .py"); return
                }
                val dir = File(filesDir, "bots").apply { mkdirs() }
                val safeName = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
                val dest = File(dir, "${System.currentTimeMillis()}_$safeName")
                contentResolver.openInputStream(uri).use { input ->
                    requireNotNull(input) { "تعذر فتح الملف" }.copyTo(dest.outputStream())
                }
                addBot(dest)
            } catch (e: Exception) { toast("تعذر إضافة الملف: ${e.message}") }
        }
    }

    private fun queryName(uri: Uri): String? {
        val cursor = contentResolver.query(uri, null, null, null, null) ?: return null
        cursor.use {
            val index = it.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (it.moveToFirst() && index >= 0) return it.getString(index)
        }
        return null
    }

    private fun addBot(file: File) {
        val tokenInput = EditText(this).apply {
            hint = "Token (اختياري إذا كان داخل الملف)"
            setHintTextColor(Color.LTGRAY); setTextColor(white)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setPadding(20, 12, 20, 12)
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(24, 12, 24, 4)
            setBackgroundColor(panel)
            addView(TextView(this@MainActivity).apply {
                text = "إعداد ${file.name}"; textSize = 17f; setTextColor(white)
            })
            addView(tokenInput)
        }
        AlertDialog.Builder(this)
            .setView(box)
            .setPositiveButton("إضافة") { _, _ ->
                val bot = Bot(UUID.randomUUID().toString(), file, tokenInput.text.toString().trim())
                bots[bot.id] = bot
                renderBots()
                status.text = "تمت إضافة ${file.name}"
            }
            .setNegativeButton("إلغاء", null).show()
    }

    private fun renderBots() {
        list.removeAllViews()
        bots.values.sortedBy { it.file.name }.forEach { bot ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(16, 14, 16, 14)
                setBackgroundColor(panel)
            }
            val name = TextView(this).apply {
                text = "🐍  ${bot.file.name}"
                textSize = 15f; setTextColor(white)
            }
            card.addView(name)
            val state = TextView(this).apply {
                text = if (bot.running) "● يعمل" else "● متوقف"
                setTextColor(if (bot.running) blue else red); textSize = 12f
            }
            card.addView(state)
            val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val run = Button(this).apply {
                text = if (bot.running) "إيقاف" else "تشغيل"
                setTextColor(white); setBackgroundColor(if (bot.running) red else blue)
                setOnClickListener { if (bot.running) stopBot(bot) else startBot(bot) }
            }
            val logs = Button(this).apply {
                text = "السجل"; setOnClickListener { showLog(bot) }
            }
            val delete = Button(this).apply {
                text = "حذف"; setOnClickListener {
                    if (bot.running) { toast("أوقف البوت أولاً"); return@setOnClickListener }
                    bots.remove(bot.id); bot.file.delete(); renderBots()
                }
            }
            actions.addView(run, LinearLayout.LayoutParams(0, 48, 1f))
            actions.addView(logs, LinearLayout.LayoutParams(0, 48, 1f))
            actions.addView(delete, LinearLayout.LayoutParams(0, 48, 1f))
            card.addView(actions)
            list.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 12 })
        }
    }

    private fun startBot(bot: Bot) {
        if (bot.running) return
        bot.running = true
        bot.log = "بدء تشغيل ${bot.file.name}\n"
        renderBots()
        executor.execute {
            try {
                val py = Python.getInstance()
                py.getModule("runner")!!.callAttr(
                    "run_script", bot.file.absolutePath, bot.token, bot.id,
                    File(filesDir, "logs").apply { mkdirs() }.absolutePath
                )
            } catch (e: Exception) {
                bot.log += "\nخطأ: ${e.message}"
            } finally {
                bot.running = false
                runOnUiThread { renderBots() }
            }
        }
        // Refresh status while the Python script is active.
        val handler = android.os.Handler(mainLooper)
        val poll = object : Runnable {
            override fun run() {
                val logFile = File(File(filesDir, "logs"), "${bot.id}.log")
                if (logFile.exists()) bot.log = try { logFile.readText() } catch (_: Exception) { bot.log }
                if (bot.running) handler.postDelayed(this, 1000)
                else renderBots()
            }
        }
        handler.post(poll)
    }

    private fun stopBot(bot: Bot) {
        try {
            Python.getInstance().getModule("runner")!!.callAttr("request_stop", bot.id)
            bot.log += "\nتم طلب الإيقاف. قد يحتاج السكربت للتعاون مع طلب الإيقاف."
            toast("تم إرسال طلب الإيقاف")
        } catch (e: Exception) { toast("تعذر إرسال طلب الإيقاف: ${e.message}") }
    }

    private fun showLog(bot: Bot) {
        val logFile = File(File(filesDir, "logs"), "${bot.id}.log")
        val content = if (logFile.exists()) try { logFile.readText() } catch (_: Exception) { bot.log } else bot.log
        val view = TextView(this).apply {
            text = content.ifBlank { "لا توجد رسائل حتى الآن" }
            setTextColor(Color.WHITE); textSize = 12f; setPadding(20, 16, 20, 16)
        }
        val scroll = ScrollView(this).apply { addView(view) }
        AlertDialog.Builder(this).setTitle("Console • ${bot.file.name}")
            .setView(scroll).setPositiveButton("إغلاق", null).show()
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    override fun onDestroy() { super.onDestroy(); executor.shutdownNow() }
}
