import os
import sys
import threading
import traceback

_stop_flags = {}
_flags_lock = threading.Lock()
_local = threading.local()

class _ThreadLogRouter:
    def write(self, text):
        stream = getattr(_local, "stream", None)
        if stream is not None:
            stream.write(text)
    def flush(self):
        stream = getattr(_local, "stream", None)
        if stream is not None:
            stream.flush()

class BotLog:
    def __init__(self, path):
        self.path = path
        os.makedirs(os.path.dirname(path), exist_ok=True)
    def write(self, text):
        if text:
            with open(self.path, "a", encoding="utf-8") as f:
                f.write(str(text))
                f.flush()
    def flush(self):
        pass

# Install one router so simultaneous bots don't overwrite each other's logs.
if not isinstance(sys.stdout, _ThreadLogRouter):
    sys.stdout = _ThreadLogRouter()
if not isinstance(sys.stderr, _ThreadLogRouter):
    sys.stderr = _ThreadLogRouter()

def request_stop(bot_id):
    with _flags_lock:
        flag = _stop_flags.get(bot_id)
        if flag:
            flag.set()

def run_script(path, token, bot_id, log_dir):
    log_path = os.path.join(log_dir, bot_id + ".log")
    stop_event = threading.Event()
    with _flags_lock:
        _stop_flags[bot_id] = stop_event

    old_stream = getattr(_local, "stream", None)
    logger = BotLog(log_path)
    _local.stream = logger
    try:
        print("HOST MALEK: تشغيل", path)
        namespace = {
            "__name__": "__main__",
            "__file__": path,
            "BOT_TOKEN": token,
            "TOKEN": token,
            "HOST_MALEK_STOP_EVENT": stop_event,
            "HOST_MALEK_SHOULD_STOP": stop_event.is_set,
            "HOST_MALEK_SLEEP": stop_event.wait,
        }
        with open(path, "r", encoding="utf-8-sig") as source:
            code = compile(source.read(), path, "exec")
        exec(code, namespace, namespace)
        print("\\nانتهى السكربت.")
    except SystemExit as exc:
        print("\\nانتهى السكربت (SystemExit):", exc)
    except Exception:
        traceback.print_exc()
    finally:
        if old_stream is None:
            try:
                del _local.stream
            except AttributeError:
                pass
        else:
            _local.stream = old_stream
        with _flags_lock:
            _stop_flags.pop(bot_id, None)
